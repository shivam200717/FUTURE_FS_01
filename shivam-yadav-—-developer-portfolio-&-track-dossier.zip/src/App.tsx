import React, { useState, useEffect } from 'react';
import {
  ExternalLink,
  Github,
  Linkedin,
  Mail,
  Phone,
  Terminal as TerminalIcon,
  Copy,
  Check,
  Download,
  Printer,
  Moon,
  Sun,
  Code2,
  Sparkles,
  Layers,
  Cpu,
  GraduationCap,
  Briefcase,
  ShieldCheck,
  Send,
  X,
  Play,
  RotateCcw
} from 'lucide-react';

interface Project {
  id: string;
  number: string;
  title: string;
  badge: string;
  badgeColor: string;
  category: 'internship' | 'interactive' | 'web';
  tags: string[];
  description: string;
  githubUrl: string;
  liveUrl: string;
}

const PROJECTS: Project[] = [
  {
    id: 'car-scroll',
    number: '#01',
    title: 'Car Scroll Animation',
    badge: 'Internship Task 01',
    badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-950/60',
    category: 'interactive',
    tags: ['HTML5', 'CSS3 Keyframes', 'DOM Scroll API'],
    description: 'Interactive web experience showcasing dynamic vehicle motion choreographed with viewport scroll physics, responsive trigger zones, and fluid CSS transitions.',
    githubUrl: 'https://github.com/shivam200717/car-scroll-animation',
    liveUrl: 'https://shivam200717.github.io/car-scroll-animation/'
  },
  {
    id: 'student-profile',
    number: '#02',
    title: 'Student User Profile System',
    badge: 'Internship Task 02',
    badgeColor: 'border-blue-500/40 text-blue-400 bg-blue-950/60',
    category: 'web',
    tags: ['HTML5', 'Modular CSS', 'UI Architecture'],
    description: 'Comprehensive student interface architecture featuring organized academic metrics, structured user identity modules, and polished responsive layouts with clean data hierarchy.',
    githubUrl: 'https://github.com/shivam200717/Student-User-Profile-2',
    liveUrl: 'https://shivam200717.github.io/Student-User-Profile-2/'
  },
  {
    id: 'restaurant-web',
    number: '#03',
    title: 'Restaurant Website',
    badge: 'Commercial Showcase',
    badgeColor: 'border-indigo-500/40 text-indigo-400 bg-indigo-950/60',
    category: 'web',
    tags: ['HTML5', 'Responsive Grid', 'CSS Styling'],
    description: 'Full culinary commercial web layout featuring visual menu categorization, elegant typography hierarchy, and intuitive customer engagement touchpoints optimized across tablet & mobile screens.',
    githubUrl: 'https://github.com/shivam200717/Restaurant-Website',
    liveUrl: 'https://shivam200717.github.io/Restaurant-Website/'
  },
  {
    id: 'scroll-hero',
    number: '#04',
    title: 'Scroll Hero',
    badge: 'Hero Mechanics',
    badgeColor: 'border-teal-500/40 text-teal-400 bg-teal-950/60',
    category: 'interactive',
    tags: ['CSS Animation', 'Interactive UX', 'Frontend UI'],
    description: 'Experimental modern hero component featuring layered parallax scroll dynamics and high-contrast cybernetic aesthetic presentation with cross-browser responsive triggers.',
    githubUrl: 'https://github.com/shivam200717/Scroll-hero',
    liveUrl: 'https://shivam200717.github.io/Scroll-hero/'
  },
  {
    id: 'website-layout',
    number: '#05',
    title: 'Modern Website Layout',
    badge: 'Layout Standards',
    badgeColor: 'border-violet-500/40 text-violet-400 bg-violet-950/60',
    category: 'web',
    tags: ['CSS Grid', 'Flexbox', 'Adaptive UI'],
    description: 'Adaptive multi-column layout system crafted with CSS Flexbox & Grid models for optimized content hierarchy, robust semantic landmarks, and multi-device usability.',
    githubUrl: 'https://github.com/shivam200717/website-layout',
    liveUrl: 'https://shivam200717.github.io/website-layout/'
  }
];

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'internship' | 'academics' | 'skills' | 'credentials'>('internship');
  const [projectFilter, setProjectFilter] = useState<'all' | 'internship' | 'interactive' | 'web'>('all');
  const [cvModalOpen, setCvModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Terminal Runner Simulation state
  const [terminalOutput, setTerminalOutput] = useState<string>(
    'System Output: Ready for recruitment review & live coding!'
  );
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  // Contact Form state
  const [formName, setFormName] = useState<string>('');
  const [formEmail, setFormEmail] = useState<string>('');
  const [formSubject, setFormSubject] = useState<string>('');
  const [formMessage, setFormMessage] = useState<string>('');
  const [isFormSubmitting, setIsFormSubmitting] = useState<boolean>(false);
  const [formSuccess, setFormSuccess] = useState<boolean>(false);

  // Toast helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    showToast(`${label} copied to clipboard!`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const runTerminalCode = () => {
    setIsExecuting(true);
    setTerminalOutput('Compiling Python 3.12 ast... Initializing candidate runtime...');
    setTimeout(() => {
      setTerminalOutput(
        '>>> Shivam Yadav initialized | SRM IST B.Tech CSE (2024-28) | Status: 100% Ready for Engineering Internship'
      );
      setIsExecuting(false);
      showToast('Python class executed successfully!');
    }, 700);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formEmail.trim() || !formMessage.trim()) {
      showToast('Please fill in all required fields.');
      return;
    }
    setIsFormSubmitting(true);
    setTimeout(() => {
      setIsFormSubmitting(false);
      setFormSuccess(true);
      showToast('Message transmitted! Draft notification logged for shivam.yadav200713@gmail.com');
    }, 800);
  };

  // Sync dark class on document html
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const filteredProjects = PROJECTS.filter((p) => {
    if (projectFilter === 'all') return true;
    if (projectFilter === 'internship') return true; // all 5 are part of Future Interns Track
    if (projectFilter === 'interactive') return p.category === 'interactive';
    if (projectFilter === 'web') return p.category === 'web';
    return true;
  });

  return (
    <div
      className={`min-h-screen transition-colors duration-200 font-sans ${
        isDarkMode
          ? 'cyber-bg-dark text-slate-100'
          : 'cyber-bg-light text-slate-900'
      }`}
    >
      {/* Top Notification / Intern Submission Banner */}
      <aside
        className={`border-b text-xs font-mono transition-colors ${
          isDarkMode
            ? 'bg-gradient-to-r from-blue-950/70 via-slate-950 to-cyan-950/70 border-cyan-500/20 text-slate-300'
            : 'bg-gradient-to-r from-blue-50 via-white to-cyan-50 border-cyan-200 text-slate-700'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-cyan-400 text-slate-950 text-[10px] font-bold uppercase tracking-wider shadow-sm">
              SUBMISSION READY
            </span>
            <span className="text-[11px] sm:text-xs">
              Future Interns Full Stack Track • Verified Repositories &amp; Clean Architecture
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setCvModalOpen(true)}
              className="text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1 transition"
            >
              Digital CV ↓
            </button>
            <a
              href="https://github.com/shivam200717?tab=repositories"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1 transition"
            >
              GitHub Repos ↗
            </a>
          </div>
        </div>
      </aside>

      {/* Global Sticky Navigation */}
      <nav
        className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors px-4 sm:px-6 lg:px-8 py-3.5 ${
          isDarkMode
            ? 'card-glass-dark border-slate-800/80'
            : 'card-glass-light border-slate-200/90'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <a href="#hero" className="flex items-center gap-3 group">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <div className="flex flex-col">
              <span className="text-sm sm:text-base font-bold font-heading flex items-center gap-1.5">
                Shivam Yadav
                <span className="text-[10px] bg-blue-500/20 text-cyan-300 font-mono px-1.5 py-0.5 rounded border border-blue-500/30">
                  DEV
                </span>
              </span>
              <span
                className={`text-[10px] font-mono uppercase ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                SRM IST • 2024-2028
              </span>
            </div>
          </a>

          {/* Nav links */}
          <div
            className={`hidden md:flex items-center space-x-6 text-xs font-mono ${
              isDarkMode ? 'text-slate-300' : 'text-slate-600'
            }`}
          >
            <a href="#hero" className="hover:text-cyan-400 transition-colors">
              /about
            </a>
            <a href="#resume-section" className="hover:text-cyan-400 transition-colors">
              /resume
            </a>
            <a href="#philosophy" className="hover:text-cyan-400 transition-colors">
              /architecture
            </a>
            <a href="#skills" className="hover:text-cyan-400 transition-colors">
              /skills
            </a>
            <a href="#projects" className="hover:text-cyan-400 transition-colors">
              /projects
            </a>
            <a href="#credentials" className="hover:text-cyan-400 transition-colors">
              /certifications
            </a>
            <a href="#contact" className="hover:text-cyan-400 transition-colors">
              /contact
            </a>
          </div>

          {/* Actions & Theme Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsDarkMode(!isDarkMode);
                showToast(isDarkMode ? 'Light mode activated' : 'Dark mode activated');
              }}
              className={`p-2 rounded-lg border text-xs transition ${
                isDarkMode
                  ? 'bg-slate-800/80 border-slate-700 text-amber-300 hover:text-white'
                  : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
              }`}
              title="Toggle theme"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            <a
              href="https://github.com/shivam200717"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-2 sm:px-3 sm:py-2 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition ${
                isDarkMode
                  ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                  : 'bg-slate-100 border-slate-300 text-slate-700 hover:text-black hover:bg-slate-200'
              }`}
            >
              <Github className="w-4 h-4" />
              <span className="hidden sm:inline">GitHub</span>
            </a>

            <a
              href="https://www.linkedin.com/in/shivam-yadav-89b846391"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-2 sm:px-3 sm:py-2 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition ${
                isDarkMode
                  ? 'bg-blue-950/40 border-blue-600/40 text-blue-300 hover:text-white hover:bg-blue-900/50'
                  : 'bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100'
              }`}
            >
              <Linkedin className="w-4 h-4" />
              <span className="hidden sm:inline">LinkedIn</span>
            </a>

            <a
              href="#contact"
              className="hidden sm:inline-flex px-3.5 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono hover:bg-cyan-500/30 transition shadow-sm font-semibold"
            >
              Hire Me →
            </a>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-16 pb-20">
        {/* Hero Section */}
        <header id="hero" className="pt-2 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <div
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-4 text-[11px] font-mono border transition ${
                  isDarkMode
                    ? 'card-glass-dark text-cyan-300 border-cyan-500/30'
                    : 'card-glass-light text-cyan-700 border-cyan-400/40'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                <span>OPEN TO OPPORTUNITIES • B.TECH CSE INTERN CANDIDATE</span>
              </div>

              <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-2 font-heading">
                Shivam{' '}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-cyan-300 to-teal-300">
                  Yadav
                </span>
              </h1>

              <p className="text-xs sm:text-sm font-mono uppercase tracking-widest text-cyan-400 mb-4 font-semibold">
                &gt; AI &amp; ML ENTHUSIAST &amp; FULL STACK DEVELOPER
              </p>

              <p
                className={`text-sm sm:text-base leading-relaxed mb-6 max-w-2xl ${
                  isDarkMode ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Enthusiastic Computer Science undergraduate at{' '}
                <strong className={isDarkMode ? 'text-white' : 'text-slate-900'}>
                  SRM IST
                </strong>{' '}
                skilled in Python, C++, DBMS, and Web Technologies with a relentless passion for AI/ML
                solutions &amp; scalable web systems. Proactively building production-grade assignment
                tasks and interactive proof-of-work systems.
              </p>

              <div className="flex flex-wrap gap-3 pt-1">
                <a
                  href="#projects"
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 hover:from-blue-500 hover:to-cyan-500 text-white font-medium text-xs font-mono glow-cyan-box transition shadow-lg"
                >
                  Explore Track Projects ↓
                </a>
                <button
                  onClick={() => setCvModalOpen(true)}
                  className={`px-5 py-3.5 rounded-xl text-xs font-mono border transition ${
                    isDarkMode
                      ? 'card-glass-dark text-cyan-300 border-cyan-500/40 hover:text-white hover:border-cyan-400'
                      : 'card-glass-light text-cyan-700 border-cyan-300 hover:text-cyan-900'
                  }`}
                >
                  View Digital CV
                </button>
                <a
                  href="#contact"
                  className={`px-5 py-3.5 rounded-xl text-xs font-mono border transition ${
                    isDarkMode
                      ? 'card-glass-dark text-slate-200 border-slate-700 hover:text-white hover:border-slate-500'
                      : 'card-glass-light text-slate-700 border-slate-300 hover:text-slate-900'
                  }`}
                >
                  Contact Shivam
                </a>
              </div>

              <div
                className={`mt-6 pt-4 border-t flex flex-wrap items-center gap-4 text-xs font-mono ${
                  isDarkMode
                    ? 'border-slate-800 text-slate-400'
                    : 'border-slate-200 text-slate-600'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <span>📍</span> Ghaziabad, UP, India
                </span>
                <span className="text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40 font-semibold">
                  SRM IST Delhi-NCR
                </span>
                <span>Available Summer &apos;25 / Fall &apos;25</span>
              </div>
            </div>

            {/* Python 3.12 Terminal Widget */}
            <div className="lg:col-span-5">
              <div
                className={`rounded-2xl border shadow-2xl p-4 sm:p-5 font-mono text-xs leading-relaxed transition ${
                  isDarkMode
                    ? 'border-slate-800 bg-[#090f1d] text-slate-300 glow-blue-box'
                    : 'border-slate-300 bg-slate-900 text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500/90"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/90"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/90"></span>
                    <span className="ml-2 text-slate-300 font-semibold flex items-center gap-1">
                      <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" /> shivam_engine.py
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400 font-bold">PYTHON 3.12</span>
                    <button
                      onClick={runTerminalCode}
                      disabled={isExecuting}
                      title="Execute class definition"
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[10px] flex items-center gap-1 transition"
                    >
                      <Play className="w-2.5 h-2.5 fill-current" />
                      <span>{isExecuting ? '...' : 'Run'}</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-1 font-mono text-xs overflow-x-auto pb-1">
                  <p>
                    <span className="text-purple-400">class</span>{' '}
                    <span className="text-cyan-300 font-semibold">SoftwareEngineer</span>:
                  </p>
                  <p className="pl-4">
                    <span className="text-purple-400">def</span>{' '}
                    <span className="text-blue-400">__init__</span>(
                    <span className="text-rose-300">self</span>):
                  </p>
                  <p className="pl-8">
                    <span className="text-rose-300">self</span>.name ={' '}
                    <span className="text-emerald-300">&quot;Shivam Yadav&quot;</span>
                  </p>
                  <p className="pl-8">
                    <span className="text-rose-300">self</span>.education ={' '}
                    <span className="text-emerald-300">&quot;SRM IST (B.Tech CSE 2024-28)&quot;</span>
                  </p>
                  <p className="pl-8">
                    <span className="text-rose-300">self</span>.skills = [
                    <span className="text-emerald-300">&quot;Full Stack Web&quot;</span>,{' '}
                    <span className="text-emerald-300">&quot;AI/ML&quot;</span>,{' '}
                    <span className="text-emerald-300">&quot;SQL&quot;</span>]
                  </p>
                  <p className="pl-8">
                    <span className="text-rose-300">self</span>.status ={' '}
                    <span className="text-cyan-300">&quot;Intern Candidate Ready&quot;</span>
                  </p>
                  <p className="pl-4 mt-2">
                    <span className="text-purple-400">def</span>{' '}
                    <span className="text-blue-400">build_future</span>(
                    <span className="text-rose-300">self</span>):
                  </p>
                  <p className="pl-8">
                    <span className="text-purple-400">return</span>{' '}
                    <span className="text-emerald-300">
                      &quot;Crafting responsive &amp; verified software.&quot;
                    </span>
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping mt-1"></span>
                  <div className="flex-1 font-mono text-cyan-300/90 break-words">
                    {terminalOutput}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Metrics Row */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div
            className={`p-5 rounded-2xl border transition ${
              isDarkMode
                ? 'card-glass-dark border-slate-800'
                : 'card-glass-light border-slate-200'
            }`}
          >
            <div className="text-xs font-mono text-slate-400">Academic Term</div>
            <div className="text-3xl font-bold mt-1 font-heading">2024-28</div>
            <div className="text-xs text-cyan-400 font-mono mt-1 font-medium">
              SRM IST B.Tech CSE
            </div>
          </div>

          <div
            className={`p-5 rounded-2xl border transition ${
              isDarkMode
                ? 'card-glass-dark border-slate-800'
                : 'card-glass-light border-slate-200'
            }`}
          >
            <div className="text-xs font-mono text-slate-400">Verified Repos</div>
            <div className="text-3xl font-bold mt-1 font-heading">5+ Repos</div>
            <div className="text-xs text-blue-400 font-mono mt-1 font-medium">
              Future Interns Track
            </div>
          </div>

          <div
            className={`p-5 rounded-2xl border transition ${
              isDarkMode
                ? 'card-glass-dark border-slate-800'
                : 'card-glass-light border-slate-200'
            }`}
          >
            <div className="text-xs font-mono text-slate-400">Simulations</div>
            <div className="text-3xl font-bold mt-1 font-heading">5+ Passed</div>
            <div className="text-xs text-indigo-400 font-mono mt-1 font-medium">
              Anthropic &amp; Forage
            </div>
          </div>

          <div
            className={`p-5 rounded-2xl border transition ${
              isDarkMode
                ? 'card-glass-dark border-slate-800'
                : 'card-glass-light border-slate-200'
            }`}
          >
            <div className="text-xs font-mono text-slate-400">Domain Focus</div>
            <div className="text-3xl font-bold mt-1 font-heading">AI &amp; Web</div>
            <div className="text-xs text-emerald-400 font-mono mt-1 font-medium">
              Algorithms + Modern UI
            </div>
          </div>
        </section>

        {/* [01] VERIFIABLE DOSSIER - Interactive Resume & Proof of Work */}
        <section id="resume-section" className="space-y-6">
          <div
            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-4 ${
              isDarkMode ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                [01] VERIFIABLE DOSSIER
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold font-heading">
                Interactive Resume &amp; <span className="text-cyan-400">Proof of Work</span>
              </h2>
              <p
                className={`text-xs sm:text-sm mt-0.5 ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Recruiter overview, verified milestones, academic transcript, and execution record
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCvModalOpen(true)}
                className={`px-3.5 py-2 rounded-xl text-xs font-mono border transition flex items-center gap-1.5 ${
                  isDarkMode
                    ? 'card-glass-dark border-cyan-500/30 text-cyan-300 hover:text-white hover:border-cyan-400'
                    : 'card-glass-light border-cyan-300 text-cyan-700 hover:text-cyan-900'
                }`}
              >
                <span>Full Screen Modal</span>
              </button>
              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-slate-950 font-bold text-xs font-mono hover:from-blue-500 transition shadow-sm flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print PDF</span>
              </button>
            </div>
          </div>

          {/* Tab Buttons */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveTab('internship')}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition ${
                activeTab === 'internship'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : isDarkMode
                  ? 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-white'
                  : 'bg-slate-100 text-slate-600 border border-slate-200 hover:text-black'
              }`}
            >
              Future Interns Track
            </button>
            <button
              onClick={() => setActiveTab('academics')}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition ${
                activeTab === 'academics'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : isDarkMode
                  ? 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-white'
                  : 'bg-slate-100 text-slate-600 border border-slate-200 hover:text-black'
              }`}
            >
              Academic Record
            </button>
            <button
              onClick={() => setActiveTab('skills')}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition ${
                activeTab === 'skills'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : isDarkMode
                  ? 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-white'
                  : 'bg-slate-100 text-slate-600 border border-slate-200 hover:text-black'
              }`}
            >
              Skill Matrix
            </button>
            <button
              onClick={() => setActiveTab('credentials')}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition ${
                activeTab === 'credentials'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : isDarkMode
                  ? 'bg-slate-900/90 text-slate-400 border border-slate-800 hover:text-white'
                  : 'bg-slate-100 text-slate-600 border border-slate-200 hover:text-black'
              }`}
            >
              Anthropic &amp; Certs
            </button>
          </div>

          {/* Tab Panel Card */}
          <div
            className={`rounded-2xl p-6 sm:p-8 border transition min-h-[220px] ${
              isDarkMode
                ? 'card-glass-dark border-slate-800'
                : 'card-glass-light border-slate-200'
            }`}
          >
            {activeTab === 'internship' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-cyan-300 border border-blue-500/30 uppercase tracking-wider font-semibold">
                      SPECIALIZED TRACK
                    </span>
                    <h3 className="text-base sm:text-lg font-bold mt-1.5 font-heading">
                      Web Development Intern Candidate — Future Interns Track
                    </h3>
                    <p
                      className={`text-xs font-mono ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      Cohorted &amp; Independent Engineering • Dec 2024 – Present
                    </p>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-3 py-1 rounded-full border border-emerald-800/40 self-start sm:self-auto font-medium">
                    Evaluation Ready
                  </span>
                </div>

                <p
                  className={`text-xs sm:text-sm leading-relaxed ${
                    isDarkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  Constructed 5 production-standard web tasks emphasizing zero layout shift,
                  responsive multi-column layouts, viewport kinematics, and clean component
                  architecture. Every project is backed by clean Git commits, README documentation,
                  and responsive testing.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div
                    className={`p-3.5 rounded-xl border transition ${
                      isDarkMode
                        ? 'bg-slate-900/90 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-[11px] font-mono text-cyan-400 font-semibold">
                      Deliverable 01: Kinematics
                    </div>
                    <div
                      className={`text-xs mt-1 leading-normal ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      Car Scroll Physics Engine with zero layout shifts.
                    </div>
                  </div>

                  <div
                    className={`p-3.5 rounded-xl border transition ${
                      isDarkMode
                        ? 'bg-slate-900/90 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-[11px] font-mono text-cyan-400 font-semibold">
                      Deliverable 02: Hierarchy
                    </div>
                    <div
                      className={`text-xs mt-1 leading-normal ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      Student User Profile layout built with modular CSS blocks.
                    </div>
                  </div>

                  <div
                    className={`p-3.5 rounded-xl border transition ${
                      isDarkMode
                        ? 'bg-slate-900/90 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-[11px] font-mono text-cyan-400 font-semibold">
                      Deliverable 03: Commercial UX
                    </div>
                    <div
                      className={`text-xs mt-1 leading-normal ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      Modern restaurant digital menu system with interactive cues.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'academics' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/50 uppercase tracking-wider font-semibold">
                      FOUR-YEAR DEGREE PROGRAM
                    </span>
                    <h3 className="text-base sm:text-lg font-bold mt-1.5 font-heading">
                      Bachelor of Technology (B.Tech) in Computer Science &amp; Engineering
                    </h3>
                    <p
                      className={`text-xs font-mono ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      SRM Institute of Science and Technology (SRM IST Delhi-NCR) • 2024 – 2028
                    </p>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 bg-cyan-950/40 px-3 py-1 rounded-full border border-cyan-800/40 font-medium">
                    Semester 2 Active
                  </span>
                </div>

                <p
                  className={`text-xs sm:text-sm leading-relaxed ${
                    isDarkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  Core academic curriculum: Data Structures &amp; Algorithms in C++ and Python,
                  Relational Database Management Systems (SQL), Object-Oriented Software Design,
                  Discrete Mathematics, Computer Architecture, and Modern AI/ML principles.
                </p>

                <div className="flex flex-wrap gap-2 pt-2">
                  <span
                    className={`px-3 py-1.5 text-xs rounded-lg border font-mono ${
                      isDarkMode
                        ? 'bg-slate-900 text-slate-300 border-slate-800'
                        : 'bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Campus: Ghaziabad, Delhi-NCR
                  </span>
                  <span
                    className={`px-3 py-1.5 text-xs rounded-lg border font-mono ${
                      isDarkMode
                        ? 'bg-slate-900 text-slate-300 border-slate-800'
                        : 'bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    Standing: Dean&apos;s Honor Track
                  </span>
                  <span
                    className={`px-3 py-1.5 text-xs rounded-lg border font-mono ${
                      isDarkMode
                        ? 'bg-slate-900 text-cyan-300 border-slate-800'
                        : 'bg-slate-100 text-cyan-800 border-slate-200'
                    }`}
                  >
                    Focus: Systems, Web &amp; AI
                  </span>
                </div>
              </div>
            )}

            {activeTab === 'skills' && (
              <div className="space-y-4">
                <h3 className="text-base font-bold font-heading">
                  Full Stack Engineering &amp; Computational Skills
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div
                    className={`p-3.5 rounded-xl border ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-xs font-mono text-cyan-400 font-bold uppercase mb-1">
                      Languages
                    </div>
                    <p
                      className={`text-xs leading-relaxed ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      Python 3, C++, C, Java fundamentals, modern ES6+ JavaScript.
                    </p>
                  </div>
                  <div
                    className={`p-3.5 rounded-xl border ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-xs font-mono text-blue-400 font-bold uppercase mb-1">
                      Frontend &amp; UI
                    </div>
                    <p
                      className={`text-xs leading-relaxed ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      HTML5 semantic markup, CSS3 Flexbox/Grid, Tailwind CSS, responsive breakpoints.
                    </p>
                  </div>
                  <div
                    className={`p-3.5 rounded-xl border ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="text-xs font-mono text-indigo-400 font-bold uppercase mb-1">
                      CS &amp; Tooling
                    </div>
                    <p
                      className={`text-xs leading-relaxed ${
                        isDarkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}
                    >
                      Data Structures &amp; Algorithms, MySQL, schema normalization, Git, GitHub
                      workflows.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'credentials' && (
              <div className="space-y-4">
                <h3 className="text-base font-bold font-heading">
                  Accredited Programs &amp; Industry Simulations
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold">Claude with Anthropic API</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        API integration, tool calling &amp; prompting
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/40">
                      Anthropic
                    </span>
                  </div>

                  <div
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold">Fundamentals of AI &amp; ML</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Supervised algorithms &amp; evaluation
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/40">
                      Accredited
                    </span>
                  </div>

                  <div
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold">GenAI Powered Data Analytics</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Dataset automation &amp; reporting
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800/40">
                      Simulation
                    </span>
                  </div>

                  <div
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-semibold">Cybersecurity Simulation</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Network posture &amp; threat mitigation
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800/40">
                      Verified
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* [02] ARCHITECTURE MINDSET - Engineering Standards & How I Think */}
        <section id="philosophy" className="space-y-6">
          <div
            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3 ${
              isDarkMode ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                [02] ARCHITECTURE MINDSET
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading">
                Engineering Standards &amp; <span className="text-cyan-400">How I Think</span>
              </h2>
              <p
                className={`text-xs sm:text-sm ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Principled development methodology from requirements analysis to performant deployment
              </p>
            </div>
            <span className="text-[11px] font-mono text-blue-400 bg-blue-950/60 border border-blue-800/40 px-3 py-1 rounded-full self-start sm:self-auto font-medium">
              SYSTEM ARCHITECTURE
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div
              className={`p-5 rounded-2xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono font-bold mb-4 border border-cyan-500/20">
                01
              </div>
              <h3 className="text-base font-bold mb-2 font-heading">Clean, Modular Frontend</h3>
              <p
                className={`text-xs leading-relaxed ${
                  isDarkMode ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                I prioritize declarative component hierarchy, mobile-first responsiveness, and
                predictable CSS patterns. Instead of bloated frameworks, I master raw web primitives
                (Flexbox, Grid, DOM lifecycle) so my web code stays fast, light, and cross-browser
                compliant.
              </p>
              <div
                className={`mt-4 pt-3 border-t text-[11px] font-mono text-cyan-400 ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}
              >
                • Semantic HTML5 • CSS Kinematics • Responsive Breakpoints
              </div>
            </div>

            <div
              className={`p-5 rounded-2xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center font-mono font-bold mb-4 border border-blue-500/20">
                02
              </div>
              <h3 className="text-base font-bold mb-2 font-heading">
                Algorithmic Efficiency &amp; Data
              </h3>
              <p
                className={`text-xs leading-relaxed ${
                  isDarkMode ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Great software lives or dies by its data structures and time complexity. Whether
                optimizing a linear search to binary log time in C++ or querying relational SQL tables
                with optimized indexes, I design logic that scales gracefully with workload.
              </p>
              <div
                className={`mt-4 pt-3 border-t text-[11px] font-mono text-blue-400 ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}
              >
                • O(n) Optimization • Relational Normalization • State Isolation
              </div>
            </div>

            <div
              className={`p-5 rounded-2xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-mono font-bold mb-4 border border-indigo-500/20">
                03
              </div>
              <h3 className="text-base font-bold mb-2 font-heading">
                Full Stack &amp; AI Integration
              </h3>
              <p
                className={`text-xs leading-relaxed ${
                  isDarkMode ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                My trajectory pairs core web systems with modern LLM capabilities. Having trained on
                Anthropic&apos;s Claude API and generative analytical pipelines, I build applications
                that leverage AI for smart contextual automation rather than simple gimmicks.
              </p>
              <div
                className={`mt-4 pt-3 border-t text-[11px] font-mono text-indigo-400 ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}
              >
                • Anthropic API • Structured JSON Output • Intelligent Workflows
              </div>
            </div>
          </div>
        </section>

        {/* [03] CAPABILITIES - Technical Proficiency */}
        <section id="skills" className="space-y-6">
          <div
            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3 ${
              isDarkMode ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                [03] CAPABILITIES
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading">
                Technical <span className="text-cyan-400">Proficiency</span>
              </h2>
              <p
                className={`text-xs sm:text-sm ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Core technologies, frameworks &amp; developer toolsets
              </p>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2.5 py-1 rounded font-bold">
              STACK v2.4
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Programming Languages */}
            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="text-[11px] font-mono text-blue-400 uppercase tracking-wider mb-3 font-semibold">
                Programming Languages
              </div>
              <div className="flex flex-wrap gap-2">
                {['Python', 'C++', 'C', 'Java'].map((lang) => (
                  <span
                    key={lang}
                    className={`px-2.5 py-1 text-xs rounded-lg border font-mono transition ${
                      isDarkMode
                        ? 'bg-slate-800/90 text-slate-200 border-slate-700 hover:border-cyan-400'
                        : 'bg-slate-100 text-slate-800 border-slate-300 hover:border-cyan-500'
                    }`}
                  >
                    {lang}
                  </span>
                ))}
              </div>
            </div>

            {/* CS Architecture & Core */}
            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-3 font-semibold">
                CS Architecture &amp; Core
              </div>
              <div className="flex flex-wrap gap-2">
                {['DSA', 'DBMS (SQL)', 'OOPs Concept', 'Algorithm Design'].map((item) => (
                  <span
                    key={item}
                    className={`px-2.5 py-1 text-xs rounded-lg border font-mono transition ${
                      isDarkMode
                        ? 'bg-slate-800/90 text-slate-200 border-slate-700 hover:border-cyan-400'
                        : 'bg-slate-100 text-slate-800 border-slate-300 hover:border-cyan-500'
                    }`}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Web Development */}
            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="text-[11px] font-mono text-indigo-400 uppercase tracking-wider mb-3 font-semibold">
                Web Development
              </div>
              <div className="flex flex-wrap gap-2">
                {['HTML5', 'CSS3', 'JavaScript', 'Responsive UI'].map((item) => (
                  <span
                    key={item}
                    className={`px-2.5 py-1 text-xs rounded-lg border font-mono transition ${
                      isDarkMode
                        ? 'bg-slate-800/90 text-slate-200 border-slate-700 hover:border-cyan-400'
                        : 'bg-slate-100 text-slate-800 border-slate-300 hover:border-cyan-500'
                    }`}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Tools & Collaboration */}
            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider mb-3 font-semibold">
                Tools &amp; Collaboration
              </div>
              <div className="flex flex-wrap gap-2">
                {['Git & GitHub', 'Teamwork', 'Communication', 'Data Analytics'].map((item) => (
                  <span
                    key={item}
                    className={`px-2.5 py-1 text-xs rounded-lg border font-mono transition ${
                      isDarkMode
                        ? 'bg-slate-800/90 text-slate-200 border-slate-700 hover:border-cyan-400'
                        : 'bg-slate-100 text-slate-800 border-slate-300 hover:border-cyan-500'
                    }`}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* [04] DELIVERABLES & ASSIGNMENT TRACK - Featured Projects */}
        <section id="projects" className="space-y-6">
          <div
            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-3 ${
              isDarkMode ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <div>
              <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                [04] DELIVERABLES &amp; ASSIGNMENT TRACK
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-heading">
                Featured <span className="text-cyan-400">Projects</span> &amp; Internship Tasks
              </h2>
              <p
                className={`text-xs sm:text-sm ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Interactive web applications &amp; architecture created for Future Interns Track
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setProjectFilter('all')}
                className={`text-xs font-mono px-3 py-1.5 rounded-lg border transition ${
                  projectFilter === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-black'
                }`}
              >
                All (5)
              </button>
              <button
                onClick={() => setProjectFilter('internship')}
                className={`text-xs font-mono px-3 py-1.5 rounded-lg border transition ${
                  projectFilter === 'internship'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-black'
                }`}
              >
                Intern Track
              </button>
              <button
                onClick={() => setProjectFilter('interactive')}
                className={`text-xs font-mono px-3 py-1.5 rounded-lg border transition ${
                  projectFilter === 'interactive'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-black'
                }`}
              >
                Animation/UX
              </button>
              <button
                onClick={() => setProjectFilter('web')}
                className={`text-xs font-mono px-3 py-1.5 rounded-lg border transition ${
                  projectFilter === 'web'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-white'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:text-black'
                }`}
              >
                Web Systems
              </button>
            </div>
          </div>

          {/* Project Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredProjects.map((project) => (
              <article
                key={project.id}
                className={`rounded-2xl p-5 border flex flex-col justify-between transition hover:-translate-y-1 ${
                  isDarkMode
                    ? 'card-glass-dark border-slate-800 hover:border-cyan-500/40'
                    : 'card-glass-light border-slate-200 hover:border-cyan-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase tracking-wider font-semibold ${project.badgeColor}`}
                    >
                      {project.badge}
                    </span>
                    <span
                      className={`text-xs font-mono ${
                        isDarkMode ? 'text-slate-500' : 'text-slate-400'
                      }`}
                    >
                      {project.number}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold font-heading">{project.title}</h3>

                  <p
                    className={`text-xs sm:text-sm mt-2 mb-4 leading-relaxed ${
                      isDarkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}
                  >
                    {project.description}
                  </p>
                </div>

                <div>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          isDarkMode
                            ? 'bg-slate-800/90 text-slate-300 border border-slate-700/60'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 rounded-xl bg-blue-600/20 border border-blue-500/40 text-cyan-300 font-mono text-xs text-center hover:bg-blue-600/30 transition flex items-center justify-center gap-1 font-semibold"
                    >
                      <span>Code Repo</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`py-2.5 rounded-xl font-mono text-xs text-center transition flex items-center justify-center gap-1 font-semibold ${
                        isDarkMode
                          ? 'bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white'
                          : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                      }`}
                    >
                      <span>Live Demo</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </article>
            ))}

            {/* GitHub Repo Callout Card */}
            <div
              className={`rounded-2xl p-5 border border-dashed flex flex-col items-center justify-center text-center transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-700'
                  : 'card-glass-light border-slate-300'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-blue-500/10 text-cyan-400 flex items-center justify-center font-mono text-lg font-bold mb-3 border border-cyan-500/20">
                &lt;/&gt;
              </div>
              <h4 className="text-base font-bold font-heading mb-1">More on GitHub</h4>
              <p
                className={`text-xs max-w-xs mb-4 ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Explore experimental scripts, algorithmic challenges, and upcoming AI web projects.
              </p>
              <a
                href="https://github.com/shivam200717?tab=repositories"
                target="_blank"
                rel="noopener noreferrer"
                className={`px-4 py-2 rounded-xl text-cyan-400 border font-mono text-xs transition flex items-center gap-1.5 font-semibold ${
                  isDarkMode
                    ? 'bg-slate-800/90 border-slate-700 hover:border-cyan-400 hover:text-cyan-300'
                    : 'bg-slate-100 border-slate-300 hover:border-cyan-500 text-cyan-600'
                }`}
              >
                <span>Browse Repositories ↗</span>
              </a>
            </div>
          </div>
        </section>

        {/* [05] VERIFIED ACHIEVEMENTS - Credentials & Certifications */}
        <section id="credentials" className="space-y-6">
          <div
            className={`border-b pb-3 ${
              isDarkMode ? 'border-slate-800' : 'border-slate-200'
            }`}
          >
            <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
              [05] VERIFIED ACHIEVEMENTS
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-heading">
              Credentials &amp; <span className="text-cyan-400">Certifications</span>
            </h2>
            <p
              className={`text-xs sm:text-sm ${
                isDarkMode ? 'text-slate-400' : 'text-slate-600'
              }`}
            >
              Verified simulations &amp; AI engineering credentials from Anthropic &amp; Forage
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Cybersecurity Job Simulation</h3>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 font-semibold">
                  VERIFIED
                </span>
              </div>
              <p className="text-xs text-cyan-300 font-mono mt-0.5 font-medium">
                Hands-on Security Analysis
              </p>
              <p
                className={`text-xs mt-1.5 leading-relaxed ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Analyzed system vulnerabilities, network security best practices, and enterprise
                threat identification.
              </p>
            </div>

            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">GenAI Powered Data Analytics</h3>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 font-semibold">
                  SIMULATION
                </span>
              </div>
              <p className="text-xs text-cyan-300 font-mono mt-0.5 font-medium">
                Data Analysis &amp; Automation
              </p>
              <p
                className={`text-xs mt-1.5 leading-relaxed ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Utilized generative AI frameworks for dataset querying, business intelligence
                discovery, and automated reporting.
              </p>
            </div>

            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Fundamentals of AI &amp; ML</h3>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 font-semibold">
                  ACCREDITED
                </span>
              </div>
              <p className="text-xs text-cyan-300 font-mono mt-0.5 font-medium">
                Intro to Artificial Intelligence
              </p>
              <p
                className={`text-xs mt-1.5 leading-relaxed ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Foundational principles of algorithmic learning, supervised models, evaluation
                metrics, and neural networks.
              </p>
            </div>

            <div
              className={`p-4 rounded-xl border transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Claude 101 Anthropic</h3>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40 font-semibold">
                  LLM CORE
                </span>
              </div>
              <p className="text-xs text-amber-300 font-mono mt-0.5 font-medium">
                Anthropic LLM Architecture
              </p>
              <p
                className={`text-xs mt-1.5 leading-relaxed ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Foundations of frontier language model usage, prompt construction techniques, and
                contextual alignment.
              </p>
            </div>

            <div
              className={`p-4 rounded-xl border md:col-span-2 transition ${
                isDarkMode
                  ? 'card-glass-dark border-slate-800'
                  : 'card-glass-light border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Claude with the Anthropic API</h3>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40 font-semibold">
                  API ENG
                </span>
              </div>
              <p className="text-xs text-indigo-300 font-mono mt-0.5 font-medium">
                AI Engineering &amp; Prompt Architecture
              </p>
              <p
                className={`text-xs mt-1.5 leading-relaxed ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-600'
                }`}
              >
                Hands-on program building with LLM APIs, function calling principles, token
                management, and structured response handling.
              </p>
            </div>
          </div>
        </section>

        {/* [06] INITIATE CONTACT - Direct Message & Verified Channels */}
        <section id="contact" className="pt-4 pb-8">
          <div
            className={`rounded-3xl p-6 sm:p-10 border max-w-5xl mx-auto glow-cyan-box transition ${
              isDarkMode
                ? 'card-glass-dark border-blue-500/30'
                : 'card-glass-light border-blue-400/40'
            }`}
          >
            <div className="text-center max-w-2xl mx-auto mb-8">
              <div className="text-xs font-mono text-cyan-400 uppercase tracking-widest mb-1 font-semibold">
                [06] INITIATE CONTACT
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading">
                Let&apos;s Build Something{' '}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-cyan-300 to-teal-300">
                  Amazing Together
                </span>
              </h2>
              <p
                className={`text-xs sm:text-sm mt-2 ${
                  isDarkMode ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Currently seeking internships, software engineering collaborations, and AI-centric
                development opportunities.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left: Direct Message Terminal */}
              <div
                className={`lg:col-span-7 rounded-2xl p-6 border transition ${
                  isDarkMode
                    ? 'bg-slate-900/90 border-slate-800'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div
                  className={`flex items-center justify-between border-b pb-3 mb-4 text-xs font-mono ${
                    isDarkMode ? 'border-slate-800' : 'border-slate-200'
                  }`}
                >
                  <span className="text-cyan-400 font-semibold flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                    Direct Message Terminal
                  </span>
                  <span
                    className={`${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}
                  >
                    DISPATCH v1.0
                  </span>
                </div>

                <form onSubmit={handleFormSubmit} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label
                        className={`block text-xs font-mono mb-1 ${
                          isDarkMode ? 'text-slate-400' : 'text-slate-600'
                        }`}
                        htmlFor="input-name"
                      >
                        Your Name *
                      </label>
                      <input
                        type="text"
                        id="input-name"
                        value={formName}
                        onChange={(e) => setFormName(e.target.value)}
                        required
                        placeholder="Alex Rivera"
                        className={`w-full text-xs rounded-xl border px-3.5 py-2.5 focus:outline-none focus:border-cyan-400 transition ${
                          isDarkMode
                            ? 'bg-slate-950 border-slate-700 text-slate-200 placeholder-slate-600'
                            : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>
                    <div>
                      <label
                        className={`block text-xs font-mono mb-1 ${
                          isDarkMode ? 'text-slate-400' : 'text-slate-600'
                        }`}
                        htmlFor="input-email"
                      >
                        Your Email *
                      </label>
                      <input
                        type="email"
                        id="input-email"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value)}
                        required
                        placeholder="alex@company.com"
                        className={`w-full text-xs rounded-xl border px-3.5 py-2.5 focus:outline-none focus:border-cyan-400 transition ${
                          isDarkMode
                            ? 'bg-slate-950 border-slate-700 text-slate-200 placeholder-slate-600'
                            : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                        }`}
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      className={`block text-xs font-mono mb-1 ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-600'
                      }`}
                      htmlFor="input-subject"
                    >
                      Subject / Opportunity
                    </label>
                    <input
                      type="text"
                      id="input-subject"
                      value={formSubject}
                      onChange={(e) => setFormSubject(e.target.value)}
                      placeholder="Internship Offer / Collaboration"
                      className={`w-full text-xs rounded-xl border px-3.5 py-2.5 focus:outline-none focus:border-cyan-400 transition ${
                        isDarkMode
                          ? 'bg-slate-950 border-slate-700 text-slate-200 placeholder-slate-600'
                          : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>

                  <div>
                    <label
                      className={`block text-xs font-mono mb-1 ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-600'
                      }`}
                      htmlFor="input-message"
                    >
                      Message *
                    </label>
                    <textarea
                      id="input-message"
                      rows={3}
                      value={formMessage}
                      onChange={(e) => setFormMessage(e.target.value)}
                      required
                      placeholder="Hi Shivam, reviewed your portfolio..."
                      className={`w-full text-xs rounded-xl border px-3.5 py-2.5 focus:outline-none focus:border-cyan-400 transition resize-none ${
                        isDarkMode
                          ? 'bg-slate-950 border-slate-700 text-slate-200 placeholder-slate-600'
                          : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={isFormSubmitting}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-500 hover:from-blue-500 hover:to-cyan-400 text-slate-950 font-bold font-mono text-xs transition shadow-md disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    <span>{isFormSubmitting ? 'Transmitting...' : 'Transmit Message →'}</span>
                  </button>

                  {formSuccess && (
                    <div className="text-xs font-mono p-3 rounded-xl bg-emerald-950/60 border border-emerald-800/50 text-emerald-300">
                      ✓ Transmission simulated! Direct mailto draft triggered for shivam.yadav200713@gmail.com.
                    </div>
                  )}
                </form>
              </div>

              {/* Right: Direct Badges */}
              <div className="lg:col-span-5 space-y-3">
                {/* Email card */}
                <div
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition group ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700/80 hover:border-cyan-400'
                      : 'bg-slate-50 border-slate-300 hover:border-cyan-500'
                  }`}
                >
                  <a
                    href="mailto:shivam.yadav200713@gmail.com"
                    className="flex-1 cursor-pointer"
                  >
                    <div
                      className={`text-[10px] font-mono uppercase ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      DIRECT EMAIL
                    </div>
                    <div className="text-xs font-semibold truncate">
                      shivam.yadav200713@gmail.com
                    </div>
                  </a>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        copyToClipboard('shivam.yadav200713@gmail.com', 'Email address')
                      }
                      title="Copy email"
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-300 transition"
                    >
                      {copiedKey === 'Email address' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <a
                      href="mailto:shivam.yadav200713@gmail.com"
                      className="text-xs text-cyan-400 font-mono font-medium hover:underline"
                    >
                      Send ↗
                    </a>
                  </div>
                </div>

                {/* Phone card */}
                <div
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition group ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700/80 hover:border-cyan-400'
                      : 'bg-slate-50 border-slate-300 hover:border-cyan-500'
                  }`}
                >
                  <a href="tel:+917982325283" className="flex-1 cursor-pointer">
                    <div
                      className={`text-[10px] font-mono uppercase ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      DIRECT PHONE
                    </div>
                    <div className="text-xs font-semibold">+917982325283</div>
                  </a>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyToClipboard('+917982325283', 'Phone number')}
                      title="Copy phone number"
                      className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-300 transition"
                    >
                      {copiedKey === 'Phone number' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <a
                      href="tel:+917982325283"
                      className="text-xs text-cyan-400 font-mono font-medium hover:underline"
                    >
                      Dial ↗
                    </a>
                  </div>
                </div>

                {/* LinkedIn card */}
                <div
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition group ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700/80 hover:border-cyan-400'
                      : 'bg-slate-50 border-slate-300 hover:border-cyan-500'
                  }`}
                >
                  <a
                    href="https://www.linkedin.com/in/shivam-yadav-89b846391"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 cursor-pointer"
                  >
                    <div
                      className={`text-[10px] font-mono uppercase ${
                        isDarkMode ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      LINKEDIN PROFILE
                    </div>
                    <div className="text-xs font-semibold">shivam-yadav-89b846391</div>
                  </a>
                  <a
                    href="https://www.linkedin.com/in/shivam-yadav-89b846391"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-cyan-400 font-mono font-medium hover:underline"
                  >
                    Connect ↗
                  </a>
                </div>

                <div
                  className={`pt-3 border-t text-center text-xs font-mono ${
                    isDarkMode
                      ? 'border-slate-800 text-slate-500'
                      : 'border-slate-200 text-slate-500'
                  }`}
                >
                  © 2026 Shivam Yadav • SRM IST Delhi-NCR • Ghaziabad, UP
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Digital CV Modal */}
      {cvModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div
            className={`max-w-3xl w-full max-h-[90vh] overflow-y-auto rounded-2xl p-6 sm:p-8 relative border shadow-2xl transition ${
              isDarkMode
                ? 'card-glass-dark border-cyan-500/40 text-slate-100'
                : 'card-glass-light border-cyan-400 text-slate-900'
            }`}
          >
            <button
              onClick={() => setCvModalOpen(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 rounded-lg bg-slate-800 text-xs font-mono transition flex items-center gap-1"
              aria-label="Close Modal"
            >
              <X className="w-4 h-4" /> Close
            </button>

            <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center font-bold text-lg text-slate-950 font-mono shadow-md">
                SY
              </div>
              <div>
                <h2 className="text-xl font-bold font-heading">
                  Shivam Yadav — Full Curriculum Vitae
                </h2>
                <p className="text-xs font-mono text-cyan-400">
                  SRM IST B.Tech CSE (2024–2028) • Full Stack &amp; AI Systems Focus
                </p>
              </div>
            </div>

            <div className="space-y-5 text-xs text-slate-300 leading-relaxed">
              <div>
                <h3 className="font-mono text-cyan-400 uppercase tracking-wider text-[11px] mb-1 font-bold">
                  Executive Summary
                </h3>
                <p className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>
                  Ambitious Computer Science undergraduate engineer at SRM IST with expertise in
                  Python, C++, HTML5/CSS3/JavaScript, DBMS (SQL), and Anthropic Claude LLM
                  Engineering. Built 5+ modular, performant projects with dedicated proof-of-work
                  repositories.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  className={`p-3.5 rounded-xl border ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-800 text-slate-200'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <span className="text-blue-400 font-mono text-[11px] font-semibold">
                    Education
                  </span>
                  <p className="font-bold text-xs mt-1">B.Tech in Computer Science &amp; Engineering</p>
                  <p className="text-slate-400">SRM IST Delhi-NCR, Ghaziabad (2024–2028)</p>
                </div>

                <div
                  className={`p-3.5 rounded-xl border ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-800 text-slate-200'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <span className="text-emerald-400 font-mono text-[11px] font-semibold">
                    Track Candidate
                  </span>
                  <p className="font-bold text-xs mt-1">Full Stack Web Development Intern</p>
                  <p className="text-slate-400">Future Interns Project Track • Available Now</p>
                </div>
              </div>

              <div>
                <h3 className="font-mono text-cyan-400 uppercase tracking-wider text-[11px] mb-2 font-bold">
                  Technical Matrix
                </h3>
                <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
                  {[
                    'Python 3',
                    'C++',
                    'JavaScript (ES6+)',
                    'Tailwind CSS',
                    'HTML5/CSS3',
                    'DSA',
                    'DBMS (SQL)',
                    'Claude Anthropic API',
                    'Git / GitHub'
                  ].map((skill) => (
                    <span
                      key={skill}
                      className={`px-2 py-1 rounded border ${
                        isDarkMode
                          ? 'bg-slate-800 text-slate-200 border-slate-700'
                          : 'bg-slate-100 text-slate-800 border-slate-300'
                      }`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div
                className={`pt-4 border-t flex flex-wrap items-center justify-between gap-3 ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}
              >
                <span className="font-mono text-slate-400 text-[11px]">
                  shivam.yadav200713@gmail.com • +91 7982325283
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      copyToClipboard(
                        'Shivam Yadav - B.Tech CSE (SRM IST)\nEmail: shivam.yadav200713@gmail.com\nPhone: +91 7982325283\nGitHub: https://github.com/shivam200717',
                        'Resume summary'
                      );
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs transition"
                  >
                    Copy Summary
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="px-4 py-2 rounded-xl bg-cyan-400 text-slate-950 font-bold font-mono text-xs hover:bg-cyan-300 transition shadow-md"
                  >
                    Print / Save PDF
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Interactive Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 pointer-events-none flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-900/95 border border-cyan-500/50 text-cyan-300 glow-cyan-box shadow-2xl transition-all">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-xs font-mono font-medium">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
